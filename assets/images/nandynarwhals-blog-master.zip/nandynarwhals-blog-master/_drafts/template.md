---
title: "Template CTF - Template Post (Misc)"
header:
  overlay_image: /assets/images/asan/nodetect/header.jpg
  overlay_filter: 0.5
  caption: "Photo credit: Blah Blah on Unsplash"
tags:
  - template
  - writeup
  - misc
---

Template tl;dr.

## Challenge Description

#### Points

200

#### Author

amon

#### Description

```
This is a template
```

## Solution

![1]({{ site.url }}{{ site.baseurl }}/assets/images/32c3/teufel/1.png){: .align-center}

Flag: **flag{this\_is\_a\_flag}**
