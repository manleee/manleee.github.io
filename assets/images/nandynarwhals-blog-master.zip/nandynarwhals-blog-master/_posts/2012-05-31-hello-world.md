---
title: "Hello World!"
header:
  image: /assets/images/1-hello-world/eddie-kopp-263580.jpg
  caption: "Photo credit: Eddie Kopp on Unsplash"
tags:
  - website
---

Back in May 2012, the first post by Hiromi was "NANDNANDNANDNAND".

I thought I would give it a little more class with this re-release of the Nandy
Narwhals blog now serving both the Nandy Narwhals and Dystopian Narwhals CTF
teams as well as my personal information security projects.

I will be migrating the entire site to this platform over the next couple of
days.

Written on 20 Aug 2017. (Backdated for posterity)
