---
title: "SECCON CTF 2014 - Welcome to SECCON (Start)"
tags:
  - seccon2014
  - writeup
  - misc
---

Sanity check challenge.

## Challenge Description

#### Points

100

#### Description

```
Welcome to SECCON

Genre Start
Points 100
Question text
The answer is "SECCON{20141206}".
答えは、「SECCON{20141206}」です。
```

#### Solution

Flag: **SECCON{20141206}**
