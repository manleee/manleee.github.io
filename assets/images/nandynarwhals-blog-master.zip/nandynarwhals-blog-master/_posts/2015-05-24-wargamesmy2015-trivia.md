---
title: "Wargames.my 2015 - Trivia"
tags:
  - wargamesmy2016
  - writeup
  - trivia
---

We are given an image of TV5 Monde.

Given that it is a trivia challenge worth 50 points, the answer should be easily
google-able:

Easily found [article](http://arstechnica.com/security/2015/04/hacked-french-tv-network-admits-blunder-that-exposed-youtube-password/)
on compromised TV5 Monde youtube account password:

Flag: **lemotdepassedeyoutube**
